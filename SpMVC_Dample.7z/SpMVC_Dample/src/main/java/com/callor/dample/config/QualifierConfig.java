package com.callor.dample.config;

public class QualifierConfig {
	public static class SERVICE {
		public static final String FILE_V1 = "fileServiceV1";
		public static final String FILE_V2 = "fileServiceV2";
	}
}
